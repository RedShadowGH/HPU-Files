.-. .-.  .--.  .----. .----.    .----. .-.     .--.  .---. .----..----. .----. .-.   .-..----..----. 
| {_} | / {} \ | {}  }| {}  \   | {}  }| |    / {} \{_   _}| {_ /  {}  \| {}  }|  `.'  || {_  | {}  }
| { } |/  /\  \| .-. \|     /   | .--' | `--./  /\  \ | |  | |  \      /| .-. \| |\ /| || {__ | .-. \
`-' `-'`-'  `-'`-' `-'`----'    `-'    `----'`-'  `-' `-'  `-'   `----' `-' `-'`-' ` `-'`----'`-' `-'
  ____ ___.____  ___________.___   _____      __________________________
|    |   \    | \__    ___/|   | /     \    /  _  \__    ___|_   _____/
|    |   /    |   |    |   |   |/  \ /  \  /  /_\  \|    |   |    __)_ 
|    |  /|    |___|    |   |   /    Y    \/    |    \    |   |        \
|______/ |_______ \____|   |___\____|__  /\____|__  /____|  /_______  /
                 \/                    \/         \/                \/ 

#######################################################################################################

FAQ:

Q: My .exe keeps dissapearing!
A: Your antivirus might have detected a fake positive which is your .exe. Disable your antivirus and try again.

Q: I think i found a bug...
A: Please report this to me on Game Jolt (@RedShadowXD), Twitter (@RedShadowTweet) or Itch.io.

Q: My game is silent!
A: Use the + and - buttons on next to your number pad to increase the volume.

More questions coming soon...